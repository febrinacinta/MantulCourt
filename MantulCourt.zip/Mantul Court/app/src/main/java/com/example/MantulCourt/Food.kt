package com.example.MantulCourt

data class Food(val ImageView: Int, val tv_harga : String, val tv_Nama_Produk : String, val tv_rating : String) {
}